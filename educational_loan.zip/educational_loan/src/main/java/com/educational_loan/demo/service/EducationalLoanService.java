package com.educational_loan.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.educational_loan.demo.model.LoanApplicationModel;
import com.educational_loan.demo.model.UserModel;
import com.educational_loan.demo.repository.LoanApplicationRepo;
import com.educational_loan.demo.repository.UserRepo;


@Service
public class EducationalLoanService {
	@Autowired
	LoanApplicationRepo r;
	public List<LoanApplicationModel> getAllvalues()
	{
		return r.findAll();
		
	}
	public LoanApplicationModel savevalues(LoanApplicationModel s)
	{
		
		return r.save(s);
		
	}
	public String deletevalues(int LoanId)
	{
		r.deleteById(LoanId);
		return "Id has been deleted";
	}
	public LoanApplicationModel getvalues(int LoanId)
	{
		return r.findById(LoanId).get();
	}
	public LoanApplicationModel updateLoan(LoanApplicationModel p)
	{
		return r.save(p);
		
	}
	
	//
	@Autowired
	UserRepo a;
	public List<UserModel> getAlluser()
	{
		return a.findAll();
		
	}
	public String deleteuser(int Id)
	{
		a.deleteById(Id);

		return "Id has been deleted";
	}
	public UserModel saveData(UserModel s)
	{
		
		return a.save(s);
		
	}
	public UserModel updateuser(UserModel p)
	{
		return a.save(p);
		
	}
	
}
