package com.educational_loan.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.educational_loan.demo.model.LoanApplicationModel;

@Repository
public interface LoanApplicationRepo extends JpaRepository <LoanApplicationModel,Integer>{

}
