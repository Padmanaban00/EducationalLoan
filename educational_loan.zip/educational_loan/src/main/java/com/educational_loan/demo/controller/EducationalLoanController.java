package com.educational_loan.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.educational_loan.demo.model.LoanApplicationModel;
import com.educational_loan.demo.model.UserModel;
import com.educational_loan.demo.service.EducationalLoanService;
@RestController
public class EducationalLoanController {
	@Autowired
	EducationalLoanService a;
	@GetMapping(value="/getloan")
	public List<LoanApplicationModel> getAllLoan()
	{
		return a.getAllvalues();
		
	}
	@PostMapping(value="/postloan")
	public LoanApplicationModel saveLoan(@RequestBody LoanApplicationModel b) 
	{
		return a.savevalues(b);
	}
	
	@DeleteMapping("/deleid/{lid}")
	public String deleteLoan(@PathVariable("lid") int loanId)
	{
		 return a.deletevalues(loanId);
	}
	@GetMapping(value="/getid1/{lid}")
	public LoanApplicationModel getLoan(@PathVariable("lid") int loanId)
	{
		return a.getvalues(loanId);
	}
	@PutMapping(value="/updateloan")
	public LoanApplicationModel updatePharmacymodel(@RequestBody LoanApplicationModel p)
	{
		return a.updateLoan(p);
	}
//	//user
	
	@GetMapping(value="/getuser")
	public List<UserModel> getAllnew()
	{
		return a.getAlluser();
		
	}
	@PostMapping(value="/postuser")
	public UserModel savenew(@RequestBody UserModel y) 
	{
		return a.saveData(y);
	}
	@DeleteMapping("/deleuserid/{id}")
	public String deletenew(@PathVariable("id") int Id)
	{
		 return a.deleteuser(Id);
	}
	@PutMapping(value="/updateuser")
	public UserModel updatePharmacymodel(@RequestBody UserModel p)
	{
		return a.updateuser(p);
	}
	

}
